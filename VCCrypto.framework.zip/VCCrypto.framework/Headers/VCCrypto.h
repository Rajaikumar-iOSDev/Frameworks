/*---------------------------------------------------------------------------------------------
*  Copyright (c) Microsoft Corporation. All rights reserved.
*  Licensed under the MIT License. See License.txt in the project root for license information.
*--------------------------------------------------------------------------------------------*/

#import <Foundation/Foundation.h>

//! Project version number for VCCrypto.
FOUNDATION_EXPORT double VCCryptoVersionNumber;

//! Project version string for VCCrypto.
FOUNDATION_EXPORT const unsigned char VCCryptoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VCCrypto/PublicHeader.h>


